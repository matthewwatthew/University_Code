﻿README:


Each of the problems have been relayed to a MatLab file name as following:
RectangleRobot.m
Problem1.m
Problem2.m
Problem3.m
Problem4.m


Nothing fancy is needed to run, just press Run on each file to see it in action.

Thanks,
-Matt J